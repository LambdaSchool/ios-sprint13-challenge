////
////  AudioController.swift
////  Experiences
////
////  Created by Ufuk Türközü on 12.04.20.
////  Copyright © 2020 Ufuk Türközü. All rights reserved.
////
//
//import UIKit
//import AVFoundation
//
//class AudioController {
//    
//    var audio: URL?
//    private var timer: Timer?
//    
//    var elapsedTime: TimeInterval?
//    var duration: TimeInterval?
//    var remainingTime: TimeInterval?
//    
//    var audioPlayer: AVAudioPlayer? {
//        didSet {
//            audioPlayer?.delegate = self
//            audioPlayer?.isMeteringEnabled = true
//        }
//    }
//    
//    var isPlaying: Bool {
//        audioPlayer?.isPlaying ?? false // single line method, you can omit the return
//    }
//    
//    var audioRecorder: AVAudioRecorder? {
//        didSet {
//            audioRecorder?.isMeteringEnabled = true
//        }
//    }
//    
//    var recordingURL: URL?
//    var isRecording: Bool {
//        audioRecorder?.isRecording ?? false
//    }
//    
//    func updateViews() {
////        playButton.isSelected = isPlaying
////        recordButton.isSelected = isRecording
//        
//        elapsedTime = audioPlayer?.currentTime ?? 0
//        duration = audioPlayer?.duration ?? 0
//        remainingTime = TimeInterval((duration ?? 0) - (elapsedTime ?? 0))
//    }
//    
//    private lazy var timeIntervalFormatter: DateComponentsFormatter = {
//        // NOTE: DateComponentFormatter is good for minutes/hours/seconds
//        // DateComponentsFormatter is not good for milliseconds, use DateFormatter instead)
//        
//        let formatting = DateComponentsFormatter()
//        formatting.unitsStyle = .positional // 00:00  mm:ss
//        formatting.zeroFormattingBehavior = .pad
//        formatting.allowedUnits = [.minute, .second]
//        return formatting
//    }()
//    
//    func prepareAudioSession() throws {
//        let session = AVAudioSession.sharedInstance()
//        try session.setCategory(.playAndRecord, options: [.defaultToSpeaker])
//        try session.setActive(true, options: []) // can fail if on a phone call, for instance
//    }
//    
//    // MARK: - Timer
//    func startTimer() {
//        timer?.invalidate()
//        timer = Timer.scheduledTimer(withTimeInterval: 0.030, repeats: true) { [weak self] (_) in
//            guard let self = self else { return }
//            
//            self.updateViews()
//            
//            if let audioPlayer = self.audioPlayer,
//                self.isPlaying == true {
//                audioPlayer.updateMeters()
//            }
//        }
//    }
//    
//    func cancelTimer() {
//        timer?.invalidate()
//        timer = nil
//    }
//    
//    // MARK: - Recorder
//    func createNewRecordingURL() -> URL {
//        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
//        let name = ISO8601DateFormatter.string(from: Date(), timeZone: .current, formatOptions: .withInternetDateTime)
//        let file = documents.appendingPathComponent(name, isDirectory: false)
//    
//        return file
//    }
//    
//    func startRecording() {
//        let recordingURL = createNewRecordingURL().appendingPathExtension("caf")
//        self.recordingURL = recordingURL
//        let audioFormat = AVAudioFormat(standardFormatWithSampleRate: 44_100, channels: 1)!
//        audioRecorder = try? AVAudioRecorder(url: recordingURL, format: audioFormat) // FIXME: error logic
//        audioRecorder?.delegate = self
//        audioRecorder?.record()
//        updateViews()
//        
//    }
//    
//    func stopRecording() {
//        audioRecorder?.stop()
//    }
//    
//    // MARK: - Playbac
//    func loadAudio() {
//        let songURL = Bundle.main.url(forResource: "piano", withExtension: "mp3")!
//        
//        audioPlayer = try? AVAudioPlayer(contentsOf: songURL)
//    }
//    
//    func play() {
//        audioPlayer?.play()
//        startTimer()
//        updateViews()
//    }
//    
//    func pause() {
//        audioPlayer?.pause()
//        cancelTimer()
//        updateViews()
//    }
//    
//    // MARK: - Actions
//    func togglePlayback(_ sender: Any) {
//        if isPlaying {
//            pause()
//        } else {
//            play()
//        }
//    }
//    
//    func updateCurrentTime(_ slider: UISlider) {
//        if isPlaying {
//            pause()
//        }
//        
//        audioPlayer?.currentTime = TimeInterval(slider.value)
//        updateViews()
//    }
//    
//    func toggleRecording(_ sender: Any) {
//        if isRecording {
//            stopRecording()
//        } else {
//            requestPermissionOrStartRecording()
//        }
//    }
//    
//}
//
//extension AudioRecorderViewController: AVAudioPlayerDelegate {
//    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
//        updateViews()
//    }
//    
//    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
//        if let error = error {
//            NSLog("Audio Player Decode Error: \(error)")
//        }
//        updateViews()
//    }
//}
//
//extension AudioController: AVAudioRecorderDelegate {
//    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
//        
//        // Setup the player to play the recording
//        if let recordingURL = recordingURL {
//            audioComments.append(recordingURL)
//            audioPlayer = try? AVAudioPlayer(contentsOf: recordingURL)
//            //FIXME: do/catch
//        }
//        updateViews()
//        commentsTableView.reloadData()
//    }
//    
//    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
//        
//        if let error = error {
//            NSLog("Audio Recorder Error: \(error)")
//        }
//        updateViews()
//    }
//}
//
//extension AudioController: UITableViewDelegate, UITableViewDataSource {
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return audioComments.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "CommentCell", for: indexPath)
//        let comment = audioComments[indexPath.row]
//        cell.textLabel?.text = "Comment \(String(indexPath.row + 1))"
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        
//        let comment = audioComments[indexPath.row]
//        
//        audioPlayer = try? AVAudioPlayer(contentsOf: comment)
//        audioPlayer?.play()
//    }
//
//}
//
