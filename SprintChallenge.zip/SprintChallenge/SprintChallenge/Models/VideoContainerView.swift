//
//  VideoContainerView.swift
//  SprintChallenge
//
//  Created by Elizabeth Wingate on 4/10/20.
//  Copyright © 2020 Lambda. All rights reserved.
//

//import UIKit
//
//class VideoContainerView: UIView {
//    var playerLayer: CALayer?
//    
//    override func layoutSublayers(of layer: CALayer) {
//        super.layoutSublayers(of: layer)
//        playerLayer?.frame = self.bounds
//    }
//}
